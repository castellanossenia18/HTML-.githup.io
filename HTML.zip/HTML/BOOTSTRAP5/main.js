<!DOCTYPE html >
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport"content="width-device-width,initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <title>Bootstrap </title>
    </head>
    <body>
        <div class="container-sm bg-primary">
        <p class="text-white">Insertos en la cuarta revolución industrial, la tecnología está presente en todos los ámbitos de la vida: aparecen la robótica, la biotecnología, la inteligencia artificial. Desaparecen profesiones y surgen nuevas. 
    
    Los jóvenes son especialmente vulnerables. En Argentina, la mitad de los jóvenes no termina el secundario, sólo 3 de cada 10 finaliza la universidad y el desempleo juvenil duplica el promedio nacional. A este contexto se suma un dato preocupante: el 52% de las empresas no encuentra los perfiles que necesita.</p>
        </div>

        <div class="container-md bg-warning">
        <p>En el marco del programa Yo puedo programar,jovenes de todo el pais aprendieron a disenar su primera pagina web y se acercaron al sector IT.</p>
        </div>

        <div class="container-lg bg-info">
        <p>Insertos en la cuarta revolución industrial, la tecnología está presente en todos los ámbitos de la vida: aparecen la robótica, la biotecnología, la inteligencia artificial. Desaparecen profesiones y surgen nuevas. 
    
    Los jóvenes son especialmente vulnerables. En Argentina, la mitad de los jóvenes no termina el secundario, sólo 3 de cada 10 finaliza la universidad y el desempleo juvenil duplica el promedio nacional. A este contexto se suma un dato preocupante: el 52% de las empresas no encuentra los perfiles que necesita.</p>
        </div>

        <div class="container-xl  bg-danger">
        <p>En el marco del programa Yo puedo programar,jovenes de todo el pais aprendieron a disenar su primera pagina web y se acercaron al sector IT.</p>
        </div>

        <div class="container-fluid bg-success">
            <p class="text-white">En el marco del programa Yo puedo programar,jovenes de todo el pais aprendieron a disenar su primera pagina web y se acercaron al sector IT.</p>
        </div>
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="boostrap.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="bootrap1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="bootraps.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<div class="contenedor">
    <!primera noticia>
    <div class="noticias">
        <h1>3,700 jovenes aprendieron a programar</h1>
        <p></p>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    
    </body>
</html>